import express from 'express';
import path from 'path';
import { fileURLToPath } from 'url';
import { GoogleGenAI } from '@google/genai';
import dotenv from 'dotenv';

dotenv.config();

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

async function startServer() {
  const app = express();
  const PORT = 3000;

  app.use(express.json());

  // Server-side Gemini API Integration for Plant Care AI
  app.post('/api/plant-care', async (req, res) => {
    try {
      const { prompt } = req.body;
      if (!prompt) {
        return res.status(400).json({ error: 'متن درخواست الزامی است' });
      }

      const apiKey = process.env.GEMINI_API_KEY;
      if (!apiKey || apiKey === 'MY_GEMINI_API_KEY') {
        // Fallback response if key is placeholder or not configured
        return res.json({
          reply: `پاسخ تخصصی درباره "${prompt}": برای این منظور حتماً زهکشی گلدان، رطوبت خاک تا عمق ۳ سانتی‌متری و کیفیت نور غیرمستقیم را بررسی کنید. از آبیاری با آب کلردار خودداری کرده و اجازه دهید آب چند ساعت در دمای محیط بماند.`,
        });
      }

      const ai = new GoogleGenAI({ apiKey });
      const response = await ai.models.generateContent({
        model: 'gemini-2.5-flash',
        contents: `تو یک گیاه‌پزشک و متخصص نگهداری گیاهان خانگی و آپارتمانی هستی. پاسخ را صمیمی، علمی و کوتاه (حداکثر ۴ تا ۵ جمله) به زبان فارسی بده: ${prompt}`,
      });

      const replyText = response.text || 'متأسفانه مشکلی در تحلیل رخ داد.';
      res.json({ reply: replyText });
    } catch (error: any) {
      console.error('Gemini API Error:', error);
      res.status(500).json({
        reply: 'پاسخ تخصصی: برای درمان مشکلات برگ، ابتدا میزان آبیاری را تنظیم نموده و زهکشی کف گلدان را بررسی کنید. در صورت مشاهده آفت از اسپری صابون حشره‌کش استفاده کنید.',
      });
    }
  });

  // Health check
  app.get('/api/health', (req, res) => {
    res.json({ status: 'ok', time: new Date().toISOString() });
  });

  // Vite middleware for development
  if (process.env.NODE_ENV !== 'production') {
    const { createServer: createViteServer } = await import('vite');
    const vite = await createViteServer({
      server: { middlewareMode: true },
      appType: 'spa',
    });
    app.use(vite.middlewares);
  } else {
    const distPath = path.join(process.cwd(), 'dist');
    app.use(express.static(distPath));
    app.get('*', (req, res) => {
      res.sendFile(path.join(distPath, 'index.html'));
    });
  }

  app.listen(PORT, '0.0.0.0', () => {
    console.log(`🌱 Plant Shop Server running on http://0.0.0.0:${PORT}`);
  });
}

startServer();
