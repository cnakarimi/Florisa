// Convert Latin numbers (0-9) to Persian digits (۰-۹)
export function toPersianDigits(input: number | string): string {
  if (input === undefined || input === null) return '';
  const str = String(input);
  const persianDigits = ['۰', '۱', '۲', '۳', '۴', '۵', '۶', '۷', '۸', '۹'];
  return str.replace(/\d/g, (x) => persianDigits[parseInt(x, 10)]);
}

// Format numbers with thousand separators in Persian
export function formatToman(price: number): string {
  const formatted = price.toLocaleString('fa-IR');
  return `${formatted} تومان`;
}

// Standard English/Latin to Persian number formatter fallback
export function formatPersianNumber(num: number): string {
  const parts = num.toString().replace(/\B(?=(\d{3})+(?!\d))/g, ',');
  return toPersianDigits(parts);
}
